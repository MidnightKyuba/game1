### Compiling using Maven 
```bash
git clone https://github.com/yogthos/Space-Invaders.git
cd Space-Invaders
mvn install
java -jar target/space-invaders-1.0.one-jar.jar
```
